<?php $title = __('Importing', 'wpomatic') ?>
<h2><?php _e('Importing', 'wpomatic') ?></h2>

<h3><?php _e('Basics', 'wpomatic') ?></h3>
<p><?php _e('Importing OPML files make it easy to make incredible campaigns in no time. An OPML is an XML format for outlines, commonly used to distribute lists of feeds.', 'wpomatic') ?></p>
