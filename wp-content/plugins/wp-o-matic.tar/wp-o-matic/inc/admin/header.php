<link rel="stylesheet" href="<?php echo $this->tplpath ?>/css/admin.css" type="text/css" media="all" title="" />
<?php if($this->newadmin): ?>
<link rel="stylesheet" href="<?php echo $this->tplpath ?>/css/admin-new.css" type="text/css" media="all" title="" />  
<?php endif ?>

<div id="wpomain">
	<p style="width: 400px">Note: Campaign is the word used to describe the organization of the feeds.  
	Currently, each campaign is associated with a wordpress category with one campaign for feeds
	submitted by users.</p>

<div id="wpocontent">
