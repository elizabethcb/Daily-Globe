  </div>
</div>

<div id="wpofooter">                                                                            
  <!-- Remove me not! -->
  <p>WP-o-Matic <?php echo $this->version ?> &mdash; Copyright &copy;2008 <a href="http://devthought.com">Guillermo Rauch</a></p>
</div>    